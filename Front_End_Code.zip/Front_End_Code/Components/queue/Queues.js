import React, {useState} from 'react'
import Queue from "./Queue";
import {CountdownCircleTimer} from 'react-countdown-circle-timer'

const Queues = () => {
    const [refreshCount, setRefreshCount] = useState(0);


    return <>
        <div className="mt-5 container">
            <div className="text-center mb-5">
                <h3>
                    Queues
                </h3>
            </div>
            <div className="timer-wrapper">
                <CountdownCircleTimer
                    size={200}
                    isPlaying
                    duration={200}
                    colors={[["#015893", 0.33], ["#f6b600", 0.33], ["#14b100"]]}
                    onComplete={() => {
                        setRefreshCount(curr => ++curr);
                        return [true, 1000];
                    }}
                >
                    {({remainingTime}) => {
                        if (remainingTime === 0) {
                            return <div className="timer">Refreshing...</div>;
                        }

                        return (
                            <div className="timer">
                                <div className="text">The page will be<br/>refreshed</div>
                                <div className="value font-weight-bold">{remainingTime}</div>
                                <div className="text">seconds</div>
                            </div>
                        );
                    }}
                </CountdownCircleTimer>
            </div>
            <div className="row justify-content-center mt-5">
                <div className="col-12 col-md-6 col-lg-4">
                    <Queue refreshCount={refreshCount} queueEndpoint="yemekhane" qTitle="Dining hall" photo="https://0c0b2eec085a.ngrok.io/yemekhane"/>
                </div>
                <div className="col-12 col-md-6 col-lg-4 mt-3 mt-md-0">
                    <Queue refreshCount={refreshCount} queueEndpoint="servis" qTitle="Service"photo="https://0c0b2eec085a.ngrok.io/servis"/>
                </div>
            </div>
        </div>
    </>
};

export default Queues;