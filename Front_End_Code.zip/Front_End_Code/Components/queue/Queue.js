import React, {useEffect, useState} from 'react'
import axios from "axios";
import {Humidity} from 'react-environment-chart';
import './Queue.css';

const Queue = ({refreshCount, queueEndpoint, qTitle, photo}) => {
    const [data, setData] = useState(undefined);
    const [error, setError] = useState(undefined);
    const [show, setShow] = useState(false);
    const [loading, setLoading] = useState(false);
    const [showPhoto, setShowPhoto] = useState(false);

    useEffect(() => {
        setLoading(true);
        axios.get("https://smartcampus3.herokuapp.com/people_count/" + queueEndpoint).then(result => {
            setData(result.data[0]);
            setError(undefined);
            setLoading(false);
        }).catch(() => {
            setError("There is a problem with the " + qTitle + " camera.");
            setData(undefined);
            setLoading(false);
        })
    }, [refreshCount, queueEndpoint, qTitle]);


    return <>

        <div className="card queue">
            <button className={show ? 'btn btn-dark' : 'btn btn-primary'}
                    onClick={() => setShow(current => !current)}> {qTitle} queue {show ? 'hide' : 'show'} people count
            </button>
            {show && <div className="card-body my-body">
                <div className="container">
                    <div className="row justify-content-center">
                        <h5 className="mb-5">Queue {qTitle}</h5>

                    </div>
                    {error && <div className="row justify-content-center">
                        <div className="alert alert-danger" role="alert"> {error} </div>
                    </div>}
                    {loading && <div className="row justify-content-center">
                        <div className="my-spinner spinner-border text-primary" role="status">
                            <span className="sr-only">Loading...</span>
                        </div>
                    </div>}
                    {!loading && <div className="row justify-content-center">
                        <div className={`"col-12 ${(show && !photo) ? "no-photo" : ''}`}>
                            <div className="row justify-content-center queue">
                                <Humidity height={120} value={data ? data.Number_of_people * 5 / 2 : 0}
                                          tips={['Available', 'Normal', 'Crowded']}/>
                            </div>
                            <div className="row justify-content-center">
                                <span>{data && ("Date: " + data.Date)}</span>
                            </div>
                            <div className="row justify-content-center">
                                <span>{data && ("Number of people: " + data.Number_of_people)}</span>
                            </div>
                            {photo && <>
                                <div className="row justify-content-center mt-3">
                                    <button className="btn btn-info"
                                            onClick={() => setShowPhoto(current => !current)}> {showPhoto ? 'Hide' : 'Show'} Photo
                                    </button>
                                </div>
                                {showPhoto && <div className="row justify-content-center mt-3">
                                    <img src={photo} width="100%" height="100%" alt={"photo-"+ queueEndpoint}/>
                                </div>}
                            </>
                            }
                        </div>
                    </div>}
                </div>
            </div>}
        </div>
    </>
};

export default Queue;