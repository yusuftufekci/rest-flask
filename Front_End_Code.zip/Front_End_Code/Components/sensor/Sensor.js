import React, {useEffect, useState} from 'react'
import axios from "axios";
import {Humidity, Temperature} from 'react-environment-chart';

const Sensor = ({refreshCount, isAdmin, classID}) => {
    const [data, setData] = useState(undefined);
    const [error, setError] = useState(undefined);
    const [show, setShow] = useState(false);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        axios.get("https://smartcampus3.herokuapp.com/api/classrooms/" + classID).then(result => {
            setData(result.data[0]);
            setError(undefined);
            setLoading(false);
        }).catch(() => {
            setError("There is a problem with the " + classID + " id class sensor.");
            setData(undefined);
            setLoading(false);
        })
    }, [classID, refreshCount]);


    return <>

        <div className="card">
            <button className={show ? 'btn btn-dark' : 'btn btn-primary'}
                    onClick={() => setShow(current => !current)}> Class {classID} {show ? 'Hide' : 'Show'} Sensor Data
            </button>
            {show && <div className="card-body">
                <div className="container">
                    <div className="row justify-content-center">
                        <h4>Class {classID}</h4>

                    </div>
                    {(error && !loading) && <div className="row justify-content-center">
                        <div className="alert alert-danger" role="alert"> {error} </div>
                    </div>}
                    {(isAdmin && data && data.Temperature > 15) && <div className="row justify-content-center">
                        <div className="alert alert-warning" role="alert"> The temperature is greater than 15 degrees
                        </div>
                    </div>}
                    {loading && <div className="row justify-content-center">
                        <div className="my-spinner spinner-border text-primary" role="status">
                            <span className="sr-only">Loading...</span>
                        </div>
                    </div>}
                    {!loading && <div className={`row ${!error ? 'no-error' : ''}`}>
                        <div className="col-12 col-md-6">
                            <div className="row justify-content-center">
                                <Temperature height={400} value={data ? data.Temperature : 0}/>
                            </div>
                            <div className="row justify-content-center">
                                <span>{data ? ("Temperature: " + data.Temperature) : "Temperature"}</span>
                            </div>
                        </div>
                        <div className="col-12 col-md-6">
                            <div className="row justify-content-center">
                                <Humidity height={100} value={data ? data.Humidity : 0}/>
                                <span>{data ? ("Humidity: " + data.Humidity) : "Humidity"}</span>
                            </div>
                            <div className="row justify-content-center sensor">
                                <Humidity height={100} value={data ? data.PeopleClass * 5 / 2 : 0}
                                          tips={['Available', 'Normal', 'Crowded']}/>
                                <span>{data ? ("People Count: " + data.PeopleClass) : "People Count"}</span>
                            </div>
                        </div>
                    </div>}
                </div>
            </div>}
        </div>
    </>
};

export default Sensor;