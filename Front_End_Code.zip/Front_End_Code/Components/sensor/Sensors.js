import React, {useState} from 'react'
import Sensor from "./Sensor";
import './Sensor.css';
import {CountdownCircleTimer} from "react-countdown-circle-timer";

const Sensors = ({isAdmin}) => {
    const [refreshCount, setRefreshCount] = useState(0);

    return <>
        <div className="mt-5 container">
            <div className="text-center mb-5">
                <h3>
                    Class List
                </h3>
            </div>
            <div className="timer-wrapper">
                <CountdownCircleTimer
                    size={200}
                    isPlaying
                    duration={10}
                    colors={[["#015893", 0.33], ["#f6b600", 0.33], ["#14b100"]]}
                    onComplete={() => {
                        setRefreshCount(curr => ++curr);
                        return [true, 1000];
                    }}
                >
                    {({remainingTime}) => {
                        if (remainingTime === 0) {
                            return <div className="timer">Refreshing...</div>;
                        }

                        return (
                            <div className="timer">
                                <div className="text">The page will be<br/>refreshed</div>
                                <div className="value font-weight-bold">{remainingTime}</div>
                                <div className="text">seconds</div>
                            </div>
                        );
                    }}
                </CountdownCircleTimer>
            </div>
            <div className="row justify-content-center mt-4">
                <div className="col-12 col-lg-6">
                    <Sensor refreshCount={refreshCount} isAdmin={isAdmin} classID="72"/>
                </div>
                <div className="col-12 col-lg-6 mt-4 mt-lg-0">
                    <Sensor refreshCount={refreshCount} isAdmin={isAdmin} classID="73"/>
                </div>
            </div>
            <div className="row justify-content-center mt-4">
                <div className="col-12 col-lg-6">
                    <Sensor refreshCount={refreshCount} isAdmin={isAdmin} classID="74"/>
                </div>
                <div className="col-12 col-lg-6 mt-4 mt-lg-0">
                    <Sensor refreshCount={refreshCount} isAdmin={isAdmin} classID="75"/>
                </div>
            </div>
        </div>
    </>
};

export default Sensors;