import React, {Component} from 'react'

export class StudyGroup extends Component {
    render() {
        return  <>
            <div className="mt-5 container">
                <div className="text-center">
                    <h3>
                        Welcome to study group page
                    </h3>
                </div>
                <div className="row justify-content-center mt-5">

                </div>
            </div>
        </>
    }
}
