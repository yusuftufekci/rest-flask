import React from 'react';
import Navigation from "./Navigation";

const Layout = (props) => {
    return <>
        <div className="p-2 d-flex justify-content-center my-header">
            <img src="logo.png" alt="logo"/>
        </div>

        <Navigation user={props.user} setUser={props.setUser}/>
        <div className="my-body-container">
            {props.children}
        </div>
        <footer className="text-center text-white fixed-bottom footer">

            <div className="container p-4"/>

            <div className="copy-right text-center p-3">
                © 2021 Copyright SmartCampus.com
            </div>
        </footer>
    </>
};

export default Layout;