import React from "react";


const Reklam = () => {
    return <div className="card mt-3">
        <div className="card-body">
            <h6 className="card-subtitle mb-2 text-muted">Ads</h6>
            <div className="container">
                <div className="my-reklam row">
                    <div className="col-6 col-lg-4"><img src="images/reklam1.jpeg" alt="Reklam1"/></div>
                    <div className="col-6 col-lg-4"><img src="images/reklam2.png" alt="Reklam2"/></div>
                    <div className="col-6 col-lg-4"><img src="images/reklam3.png" alt="Reklam3"/></div>
                </div>
            </div>
        </div>
    </div>
}

export default Reklam;